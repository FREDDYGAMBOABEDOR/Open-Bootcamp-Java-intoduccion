import java.util.Scanner;

import static java.time.Clock.system;

public class Main {

    public static void main(String[] args) {
     Scanner entrada = new Scanner(System.in);
      System.out.println("Escribe el número : ");

        int numero = entrada.nextInt();

        if(numero < 0 ){
            System.out.println("Es negativo ");

        }
        else if (numero > 0 ){
            System.out.println("Es positivo");
        }
        else {
            System.out.println("Es neutro");
        }



        System.out.println("Ciclo while");

        int numeroWhile = 0;

        while(numeroWhile < 3){

            System.out.println(numeroWhile);
                    numeroWhile = numeroWhile + 1;}

        System.out.println("Ciclo Do while");
        int numerodoWhile = 0;
        do {

            System.out.println(numerodoWhile);
            numerodoWhile = numerodoWhile + 1;
        } while(numerodoWhile < 3);

        System.out.println("Numero for");
        for (int numeroFor = 0 ; numeroFor <= 3 ; numeroFor++){

            System.out.println(numeroFor);

        }
        System.out.println(" Switch");

        Scanner entradaEs = new Scanner(System.in);
        System.out.println("Escribe estacion  : ");
        var estacion = entradaEs.nextLine();
        switch (estacion) {
            case "Otoño": {
                System.out.println("Estas en "+ estacion);
                break;
            }

            case "Verano": {
                System.out.println("Estas en " + estacion);
                break;
            }


            case "Invierno": {
                System.out.println("Estas en " + estacion);
                break;
            }
            default: {
                System.out.println("Estas en default");
                break;
            }

        }
    }
}
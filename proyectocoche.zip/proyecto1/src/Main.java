public class Main {
    public static void main(String[] args) {
    coche Micoche = new coche();
        Micoche.AumPuertas();

        System.out.println("El coche tiene " + Micoche.puertas + " puerta");

    }


}

class coche {
public int puertas = 0;
public void AumPuertas (){
    this.puertas++;
    }
}



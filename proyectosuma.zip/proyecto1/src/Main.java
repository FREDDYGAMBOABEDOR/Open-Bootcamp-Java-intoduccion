public class Main {
    public static void main(String[] args) {
        int valor1 = 5;
        int valor2 = 7;
        int valor3 = 10;

        var resul = suma ( valor1, valor2, valor3) ;

        System.out.println(resul);

    }

    public static int suma(int a, int b, int c) {

        return a + b + c;

    }
}




